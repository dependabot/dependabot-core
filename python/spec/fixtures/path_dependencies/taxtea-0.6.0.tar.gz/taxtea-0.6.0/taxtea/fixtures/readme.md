SaaS States determined by [this taxjar link](https://blog.taxjar.com/saas-sales-tax/)
