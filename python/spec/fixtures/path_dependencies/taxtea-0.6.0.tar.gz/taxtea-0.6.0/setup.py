# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['taxtea', 'taxtea.migrations', 'taxtea.services']

package_data = \
{'': ['*'], 'taxtea': ['fixtures/*']}

install_requires = \
['django-localflavor>=3.0.1,<4.0.0',
 'django>=3.0.5,<4.0.0',
 'httpx>=0.12.1,<0.13.0',
 'xmltodict>=0.12.0,<0.13.0']

setup_kwargs = {
    'name': 'taxtea',
    'version': '0.6.0',
    'description': 'TaxTea - A Django Tax App for Saas',
    'long_description': None,
    'author': 'Matt Strayer',
    'author_email': 'git@mattstrayer.com',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.8.0,<4.0.0',
}


setup(**setup_kwargs)
